""" This package contains objects that are common to Modules and Managers.
Most are container objects. """