class MessageError(Exception):
    pass
        
class ManualException(Exception):
    pass

class ManualRestartException(Exception):
    pass

class RolloverException(Exception):
    pass

class FatalError(Exception):
    pass