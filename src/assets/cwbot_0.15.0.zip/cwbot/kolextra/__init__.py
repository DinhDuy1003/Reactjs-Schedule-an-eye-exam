""" This package holds replacements and additions to PyKol (instead of 
modifying the kol package). """